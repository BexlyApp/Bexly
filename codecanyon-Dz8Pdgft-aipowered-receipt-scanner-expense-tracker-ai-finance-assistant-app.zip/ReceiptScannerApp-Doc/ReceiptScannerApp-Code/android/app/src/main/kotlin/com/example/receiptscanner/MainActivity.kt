package com.example.receiptscanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
