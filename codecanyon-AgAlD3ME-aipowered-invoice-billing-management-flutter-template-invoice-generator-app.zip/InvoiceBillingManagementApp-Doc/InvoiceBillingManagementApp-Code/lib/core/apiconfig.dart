const String apiKey =
    "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"; // Replace with your Groq API key
const String geminiApiKey = "AIzaSyCMK7RTPGB2S3YowLkUGh8aYSi4G_bZJsg";
// Replace with your Groq API key

class ApiConstants {
  // Replace with your Groq API key
  static const String apiKey =
      "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";
  static const String geminiApiKey = "AIzaSyCMK7RTPGB2S3YowLkUGh8aYSi4G_bZJsg";
}
