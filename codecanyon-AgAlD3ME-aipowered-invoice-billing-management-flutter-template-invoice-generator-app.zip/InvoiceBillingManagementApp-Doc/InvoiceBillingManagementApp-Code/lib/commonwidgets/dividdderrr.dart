import 'package:flutter/material.dart';

class Dividddddddddddeeeeeerrrrrr extends StatelessWidget {
  const Dividddddddddddeeeeeerrrrrr({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Divider(
      color: Colors.grey[700],
    );
  }
}
